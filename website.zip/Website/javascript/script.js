document.getElementsByTagName('h1')[0].onmouseout = function () {
            this.innerText= 'Button' ; this.style.color='Black'}